/**
 * 
 */
package org.bonitasoft.connector.fredk;

import groovy.lang.GroovyShell;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import java.util.logging.Logger;



import org.bonitasoft.engine.connector.ConnectorException;

/**
 *The connector execution will follow the steps
 * 1 - setInputParameters() --> the connector receives input parameters values
 * 2 - validateInputParameters() --> the connector can validate input parameters values
 * 3 - connect() --> the connector can establish a connection to a remote server (if necessary)
 * 4 - executeBusinessLogic() --> execute the connector
 * 5 - getOutputParameters() --> output are retrieved from connector
 * 6 - disconnect() --> the connector can close connection to remote server (if any)
 */
public class ExecuteExternalGroovyScriptImpl extends
		AbstractExecuteExternalGroovyScriptImpl {

	@Override
	protected void executeBusinessLogic() throws ConnectorException{
		//Get access to the connector input parameters
		//getPathToFile();
		//getInputMap();
		//getInputMapDescription();
	
		//TODO execute your business logic here 
		Logger log = Logger.getLogger ("org.bonitasoft.debug");
		log.severe (" DEBUG - START ExecuteExternalGroovyScriptImpl " );
		
		
	    InputStream ips;
		try {
			log.severe (" DEBUG - getPathToFile(): " + getPathToFile());
			ips = new FileInputStream(getPathToFile());
		    InputStreamReader ipsr = new InputStreamReader(ips);
		    BufferedReader br = new BufferedReader(ipsr);		
		    
		    String chaine = "";
		    String ligne;
		    while ((ligne = br.readLine()) != null)
		    {
		      System.out.println(ligne);
		      chaine = chaine + ligne + "\n";
		    }
		    br.close();

		    GroovyShell gs = new GroovyShell();

		    //inputMap is the name of the input data variable pass to the external script
		    gs.setProperty("inputMap", getInputMap());

		    Object result = gs.evaluate(chaine);

			//WARNING : Set the output of the connector execution. If outputs are not set, connector fails
			//setResult(result);		    
		    setResult(result);
		    
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			log.severe (" DEBUG - FileNotFoundException:  " + e.toString());
			e.printStackTrace();
		} catch (IOException e) {
			log.severe (" DEBUG - IOException: " + e.toString());
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		



		
		
		
	

	
	 }

	@Override
	public void connect() throws ConnectorException{
		//[Optional] Open a connection to remote server
	
	}

	@Override
	public void disconnect() throws ConnectorException{
		//[Optional] Close connection to remote server
	
	}

}
