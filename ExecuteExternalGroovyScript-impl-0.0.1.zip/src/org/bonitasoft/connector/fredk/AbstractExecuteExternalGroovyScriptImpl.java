package org.bonitasoft.connector.fredk;

import org.bonitasoft.engine.connector.AbstractConnector;
import org.bonitasoft.engine.connector.ConnectorValidationException;

public abstract class AbstractExecuteExternalGroovyScriptImpl extends
		AbstractConnector {

	protected final static String PATHTOFILE_INPUT_PARAMETER = "pathToFile";
	protected final static String INPUTMAP_INPUT_PARAMETER = "inputMap";
	protected final static String INPUTMAPDESCRIPTION_INPUT_PARAMETER = "inputMapDescription";
	protected final String RESULT_OUTPUT_PARAMETER = "result";

	protected final java.lang.String getPathToFile() {
		return (java.lang.String) getInputParameter(PATHTOFILE_INPUT_PARAMETER);
	}

	protected final java.util.Map getInputMap() {
		return (java.util.Map) getInputParameter(INPUTMAP_INPUT_PARAMETER);
	}

	protected final java.lang.String getInputMapDescription() {
		return (java.lang.String) getInputParameter(INPUTMAPDESCRIPTION_INPUT_PARAMETER);
	}

	protected final void setResult(java.lang.Object result) {
		setOutputParameter(RESULT_OUTPUT_PARAMETER, result);
	}

	@Override
	public void validateInputParameters() throws ConnectorValidationException {
		try {
			getPathToFile();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("pathToFile type is invalid");
		}
		try {
			getInputMap();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException("inputMap type is invalid");
		}
		try {
			getInputMapDescription();
		} catch (ClassCastException cce) {
			throw new ConnectorValidationException(
					"inputMapDescription type is invalid");
		}

	}

}
